package com.summer.dot;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileSystemView;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class DotGUI extends JFrame {

    private JPanel contentPane;
    static JTextField sadr;
    static JTextField tadr;
    static JTextField dw;
    static JTextField dk;
    static JTextArea out;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    DotGUI frame = new DotGUI();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public DotGUI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 773, 702);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);

        JLabel lblNewLabel = new JLabel("s串地址：");

        sadr = new JTextField();
        sadr.setText("/Users/summerchaser/Desktop/gene.fa");
        sadr.setColumns(10);

        JLabel lblT = new JLabel("t串地址：");

        tadr = new JTextField();
        tadr.setText("/Users/summerchaser/Desktop/gene.fa");
        tadr.setColumns(10);

        JLabel label = new JLabel("窗长 ：");

        dw = new JTextField();
        dw.setText("5");
        dw.setColumns(10);

        JLabel lblNewLabel_1 = new JLabel("阈值：");

        dk = new JTextField();
        dk.setText("3");
        dk.setColumns(10);

        JButton button = new JButton("运行");
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                StringBuffer s = new StringBuffer(); // s串
                StringBuffer t = new StringBuffer(); // t串
                List<String> dotPoint = new ArrayList<String>(); // 记录点对
                List<String> record = new ArrayList<String>(); // 记录访问过的点对
                List<ArrayList<String>> subQue = new ArrayList<ArrayList<String>>(); // 存储子串
                out.setText("");
                InputStream fs = null;
                try {
                    fs = new FileInputStream(sadr.getText());
                } catch (FileNotFoundException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                InputStream ft = null;
                try {
                    ft = new FileInputStream(tadr.getText());
                } catch (FileNotFoundException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                int c;
                try {
                
                    while ((c = fs.read()) != -1   )  {
                        s.append((char) c);
                    }
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                try {
                    while ((c = ft.read()) != -1) {
                        t.append((char) c);
                    }
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                out.append("s串为： " + s + "\n");
                out.append("t串为： " + t + "\n");
                out.append("点阵图如下： " + "\n");
                int w = Integer.valueOf(dw.getText());// 窗长为5
                int k = Integer.valueOf(dk.getText());// 阈值为3
                out.append("  " + s + "\n");
                for (int m = 0; m < s.length() - w + 1; m++) {
                    out.append(t.charAt(m) + " ");
                    for (int n = 0; n < t.length() - w + 1; n++) {

                        int cnt = 0;
                        boolean flag = false;
                        for (int i = 0; i < w; i++) {
                            if (s.charAt(m + i) == t.charAt(n + i)) {
                                cnt++;
                            }
                            if (cnt >= k) {
                                flag = true;
                                break;
                            }
                        }
                        if (flag) {
                            dotPoint.add(m + "#" + n);
                            out.append("1");
                        } else {
                            out.append(" ");
                        }
                    }
                    out.append("\n");
                }

                for (String p : dotPoint) {

                    String[] xy = p.split("#");
                    int x = Integer.parseInt(xy[0]);
                    int y = Integer.parseInt(xy[1]);
                    // System.out.println(x+" "+y);

                    if (!record.contains(p)) {
                        record.add(p);
                        ArrayList<String> po = new ArrayList<String>();
                        po.add(p);

                        while (true) {
                            x++;
                            y++;
                            String next = x + "#" + y;
                            boolean a = dotPoint.contains(next);
                            boolean b = record.contains(next);
                            if (dotPoint.contains(next) && (!record.contains(next))) {
                                record.add(next);
                                po.add(next);
                            } else {
                                break;
                            }

                        }
                        subQue.add(po);
                    }

                }
                Collections.sort(subQue, new Comparator<ArrayList<String>>() {
                    
                    @Override
                    public int compare(ArrayList<String> o1, ArrayList<String> o2) {
                        Integer l1 = o1.size();
                        Integer l2 = o2.size();
                        return l2.compareTo(l1);
                    }

                
            });
                out.append("共有" + subQue.size() + "个子串： 其中最长的五条为：" + "\n");
                int cnt = 1;
                for (List<String> po : subQue) {
                    if (cnt>5) {break;}
                    for (String dot : po) {
                        String[] d = dot.split("#");
                        int dx = Integer.parseInt(d[0]);
                        int dy = Integer.parseInt(d[1]);
                        out.append("(" + dx + "," + dy + ") ");
                    }
                    cnt++;
                    out.append("\n");
                }
                
                try {
                    // 请在这修改文件输出路径
                    File fo = new File("/Users/summerchaser/Desktop/dot_out.txt");
                    FileWriter fileWriter = new FileWriter(fo);
                    fileWriter.write(out.getText());
                    fileWriter.close(); // 关闭数据流
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
               
               

            
        });

        JLabel label_1 = new JLabel("运行结果：");

        JScrollPane scrollPane = new JScrollPane();
        GroupLayout gl_contentPane = new GroupLayout(contentPane);
        gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(
                Alignment.TRAILING,
                gl_contentPane.createSequentialGroup().addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
                        .addGroup(gl_contentPane.createSequentialGroup().addContainerGap().addComponent(button,
                                GroupLayout.PREFERRED_SIZE, 95, GroupLayout.PREFERRED_SIZE))
                        .addGroup(gl_contentPane.createSequentialGroup().addGap(32).addGroup(gl_contentPane
                                .createParallelGroup(Alignment.LEADING)
                                .addGroup(gl_contentPane.createSequentialGroup().addComponent(lblNewLabel)
                                        .addPreferredGap(ComponentPlacement.UNRELATED)
                                        .addComponent(sadr, GroupLayout.DEFAULT_SIZE, 398, Short.MAX_VALUE))
                                .addGroup(gl_contentPane.createSequentialGroup()
                                        .addPreferredGap(ComponentPlacement.RELATED)
                                        .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                                                .addComponent(label_1)
                                                .addGroup(gl_contentPane.createSequentialGroup().addComponent(lblT)
                                                        .addPreferredGap(ComponentPlacement.UNRELATED)
                                                        .addComponent(tadr, GroupLayout.DEFAULT_SIZE, 297,
                                                                Short.MAX_VALUE)))))
                                .addGap(28)
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING).addComponent(label)
                                        .addComponent(lblNewLabel_1))
                                .addGap(18)
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                                        .addComponent(dw, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
                                                GroupLayout.PREFERRED_SIZE)
                                        .addComponent(dk, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
                                                GroupLayout.PREFERRED_SIZE))))
                        .addGap(30))
                .addGroup(gl_contentPane.createSequentialGroup().addGap(23)
                        .addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 710, GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(30, Short.MAX_VALUE)));
        gl_contentPane.setVerticalGroup(gl_contentPane
                .createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane.createSequentialGroup().addGap(22)
                        .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE).addComponent(lblNewLabel)
                                .addComponent(dw, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
                                        GroupLayout.PREFERRED_SIZE)
                                .addComponent(label).addComponent(sadr, GroupLayout.PREFERRED_SIZE,
                                        GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(ComponentPlacement.UNRELATED)
                        .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
                                .addComponent(dk, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
                                        GroupLayout.PREFERRED_SIZE)
                                .addComponent(tadr, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
                                        GroupLayout.PREFERRED_SIZE)
                                .addComponent(lblT).addComponent(lblNewLabel_1))
                        .addGap(18)
                        .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE).addComponent(button)
                                .addComponent(label_1))
                        .addPreferredGap(ComponentPlacement.UNRELATED)
                        .addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 503, GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(22, Short.MAX_VALUE)));

        out = new JTextArea();
        scrollPane.setViewportView(out);
        contentPane.setLayout(gl_contentPane);
    }
}
